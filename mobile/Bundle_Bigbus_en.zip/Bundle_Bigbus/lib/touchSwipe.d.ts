/**
 * Created by Zsolt on 2015.10.10..
 */

///<reference path="jquery.d.ts"/>

interface JQuery {
    /**
     * Creates a bxSlider from the current element.
     * @param options
     */
    swipe(options?:any): any;
}
